/**
 * 
 */
package com.myprojects.utilitysvc.service;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Date;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.myprojects.utilitysvc.Entity.FileMetaData;


/**
 * @author gks
 *
 */
@Service
@Scope("prototype")
@PropertySource("classpath:application.properties")
public class FileServiceImpl implements FileService {
	
	private static final Logger LOG = LoggerFactory.getLogger(FileServiceImpl.class);
	
	@Value("${File.Store.Path}")
	String fileStorePath;
	
	@Value("${FileMetaData.Store.Path}")
	String fileMetaDataStorePath;
	

	/* (non-Javadoc)
	 * @see com.myprojects.utilitysvc.service.FileService#getFileMetaData()
	 */
	@Override
	public String getFileMetaData() throws Exception {
		// TODO Auto-generated method stub
		String fileMetaData = "fileMetaData";
		return fileMetaData;
	}

	/* (non-Javadoc)
	 * @see com.myprojects.utilitysvc.service.FileService#saveFileMetaData()
	 */
	@Override
	public Boolean saveFileMetaData() throws Exception {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public String saveFile(MultipartFile file,String uploadedUserName) throws Exception {
		// TODO Auto-generated method stub
		String origFileName  = file.getOriginalFilename();
		String fileName = file.getName();
		long fileSize = file.getSize();
		String contentType = file.getContentType();
		LOG.debug("origFileName:"+origFileName);
		LOG.debug("fileName:"+fileName);
		LOG.debug("fileSize:"+fileSize);
		LOG.debug("contentType:"+contentType);
		byte[] uploadedContent = file.getBytes();
		LOG.debug("fileStorePath:"+fileStorePath);
		Path path = Paths.get(fileStorePath + file.getOriginalFilename());
		if(Files.exists(path.getParent())){
			 Files.write(path, uploadedContent);
		}else{
			Files.createDirectory(path.getParent());
			Files.createFile(path);
			Files.write(path, uploadedContent);
		}
       

		//file.transferTo(new File("/MyProjects/Files/"));
		FileMetaData fileMetaData = new FileMetaData();
		fileMetaData.setName(origFileName);
		fileMetaData.setOrigName(origFileName);
		fileMetaData.setSize(fileSize);
		fileMetaData.setContentType(contentType);
		fileMetaData.setFileUploadTime(new Date());
		fileMetaData.setFileUploadedBy(uploadedUserName);
		
		ObjectMapper mapper = new ObjectMapper(); 
		String fileMetaDataStr = mapper.writeValueAsString(fileMetaData);
		LOG.info(fileMetaDataStr);
		String content = fileMetaDataStr;
		Path fileMetaDataPath = Paths.get(fileMetaDataStorePath + origFileName+"_MetaData.txt");
		LOG.debug("fileMetaDataStorePath:"+fileMetaDataStorePath);
		if(Files.exists(fileMetaDataPath.getParent())){
			Files.write( fileMetaDataPath, content.getBytes(), StandardOpenOption.CREATE);
		}else{
			Files.createDirectory(fileMetaDataPath.getParent());
			Files.createFile(fileMetaDataPath);
			Files.write(fileMetaDataPath, content.getBytes());
		}
		return fileMetaDataStr;
	}

}
