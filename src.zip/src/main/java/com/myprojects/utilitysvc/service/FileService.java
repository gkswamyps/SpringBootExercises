package com.myprojects.utilitysvc.service;

import java.io.File;

import org.springframework.web.multipart.MultipartFile;

import com.myprojects.utilitysvc.Entity.FileMetaData;


public interface FileService {
	
	String getFileMetaData() throws Exception;
	Boolean saveFileMetaData() throws Exception;
	String saveFile(MultipartFile file,String uploadedUserName) throws Exception;
	

}
