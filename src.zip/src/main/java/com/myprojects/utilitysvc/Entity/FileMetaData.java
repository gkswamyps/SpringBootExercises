package com.myprojects.utilitysvc.Entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class FileMetaData {

		String name;
		String origName;
		long size;
		@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd@HH:mm:ss", timezone="America/NewYork")
		Date fileUploadTime;
		String fileUploadedBy;
		String contentType;
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getOrigName() {
			return origName;
		}
		public void setOrigName(String origName) {
			this.origName = origName;
		}
		public long getSize() {
			return size;
		}
		public void setSize(long size) {
			this.size = size;
		}
		public Date getFileUploadTime() {
			return fileUploadTime;
		}
		public void setFileUploadTime(Date fileUploadTime) {
			this.fileUploadTime = fileUploadTime;
		}
		public String getFileUploadedBy() {
			return fileUploadedBy;
		}
		public void setFileUploadedBy(String fileUploadedBy) {
			this.fileUploadedBy = fileUploadedBy;
		}
		public void setContentType(String contentType) {
			
			this.contentType = contentType;
		}
		public String getContentType() {
			return contentType;
		}
}
